from distutils.core import setup

setup(
    name='pyDiscreteProbability',
    version='0.6.dev.f8248b9',
    author='Viet Nguyen',
    author_email='vnguyen@cs.ucla.edu',
    packages=['discrete_probability'],
    scripts=[],
    url='http://pypi.python.org/pypi/pyDiscreteProbability/',
    license='LICENSE.txt',
    description='Discrete probability learning and inference in Python.',
    long_description=open('README.md').read(),
    install_requires=[
    ],
)

